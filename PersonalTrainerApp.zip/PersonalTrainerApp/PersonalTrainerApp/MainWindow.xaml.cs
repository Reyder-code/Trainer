﻿using System.Windows;
using System.Windows.Controls.Primitives;

namespace PersonalTrainerApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // Устанавливаем стартовую страницу
            MainFrame.Content = new MenuPage();
        }
    }
}
