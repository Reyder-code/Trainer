﻿using System.Collections.Generic;

namespace PersonalTrainerApp
{
    public class TrainingPlan
    {
        public int Id { get; set; }
        public string PlanName { get; set; }
        public string Goal { get; set; }
        public List<TrainingDay> Days { get; set; } = new List<TrainingDay>();
    }

    public class TrainingDay
    {
        public int Id { get; set; }
        public string DayName { get; set; }
        public List<Exercise> Exercises { get; set; } = new List<Exercise>();
    }

    public class Exercise
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Sets { get; set; }
        public int Reps { get; set; }
        public int RestSeconds { get; set; }
    }
}
