﻿using System.Windows;
using System.Windows.Controls;

namespace PersonalTrainerApp
{
    public partial class MenuPage : Page
    {
        public MenuPage()
        {
            InitializeComponent();
        }

        private void NavigateToCreatePlan(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new CreatePlanPage());
        }

        private void NavigateToMyPlans(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MyPlansPage());
        }

        private void NavigateToStatistics(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new StatisticsPage());
        }

        private void ExitApplication(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
