﻿using System.Collections.Generic;
using System.Linq;

public class TrainingPlan
{
    public string Goal { get; set; }
    public int TrainingDays { get; set; }
    public List<TrainingDay> Days { get; set; } = new List<TrainingDay>();
}

public class TrainingDay
{
    public string DayName { get; set; }
    public List<Exercise> Exercises { get; set; } = new List<Exercise>();
}

public class Exercise
{
    public string Name { get; set; }
    public int Sets { get; set; }
    public int Reps { get; set; }
    public int RestSeconds { get; set; }
}

    public class PlanGenerator
    {
        public TrainingPlan GeneratePlan(string goal, int trainingDays, string level)
        {
            var plan = new TrainingPlan
            {
                Goal = goal,
                TrainingDays = trainingDays
            };

            var exercises = GetExercisesByGoalAndLevel(goal, level);
            var dayNames = new[] { "День 1", "День 2", "День 3", "День 4", "День 5", "День 6", "День 7" };

            // Проверяем, достаточно ли упражнений
            int exercisesPerDay = 3; // Упражнений на день
            int totalDays = trainingDays;

            for (int i = 0; i < totalDays; i++)
            {
                var day = new TrainingDay { DayName = dayNames[i] };

                // Если упражнений недостаточно, начинаем использовать их заново
                for (int j = 0; j < exercisesPerDay; j++)
                {
                    day.Exercises.Add(exercises[(i * exercisesPerDay + j) % exercises.Count]);
                }

                plan.Days.Add(day);
            }

            return plan;
        }

        private List<Exercise> GetExercisesByGoalAndLevel(string goal, string level)
        {
            // Пример упражнений
            var allExercises = new List<Exercise>
            {
                new Exercise { Name = "Приседания", Sets = 3, Reps = 12, RestSeconds = 60 },
                new Exercise { Name = "Жим лежа", Sets = 3, Reps = 10, RestSeconds = 90 },
                new Exercise { Name = "Становая тяга", Sets = 4, Reps = 8, RestSeconds = 120 },
                new Exercise { Name = "Подтягивания", Sets = 3, Reps = 12, RestSeconds = 60 },
                new Exercise { Name = "Бег на дорожке", Sets = 1, Reps = 20, RestSeconds = 0 }, // 20 минут
                new Exercise { Name = "Жим гантелей стоя", Sets = 3, Reps = 10, RestSeconds = 60 }
            };

            // Фильтруем упражнения по цели
            if (goal == "Снижение веса")
            {
                return allExercises.FindAll(e => e.Name.Contains("Бег") || e.Reps > 10);
            }
            else if (goal == "Набор массы")
            {
                return allExercises.FindAll(e => !e.Name.Contains("Бег"));
            }

            // Для других целей возвращаем все упражнения
            return allExercises;
        }
    }


