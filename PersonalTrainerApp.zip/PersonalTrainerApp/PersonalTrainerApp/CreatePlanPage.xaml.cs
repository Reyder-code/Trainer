﻿using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;

namespace PersonalTrainerApp
{
    public partial class CreatePlanPage : Page
    {
        private const string PlansFilePath = "plans.json";

        public CreatePlanPage()
        {
            InitializeComponent();
        }

        private void GeneratePlanButton_Click(object sender, RoutedEventArgs e)
        {
            var goal = GoalComboBox.SelectedItem.ToString();
            var days = (int)DaysSlider.Value;
            var level = LevelComboBox.SelectedItem.ToString();

            var generator = new PlanGenerator();
            var plan = generator.GeneratePlan(goal, days, level);

            // Отобразить план (например, на новой странице или в окне)
            MessageBox.Show($"План создан: {plan.Days.Count} тренировочных дней");
        }

        private void SavePlans(List<TrainingPlan> plans)
        {
            var json = JsonSerializer.Serialize(plans);
            File.WriteAllText(PlansFilePath, json);
        }

        private void SavePlan(object sender, RoutedEventArgs e)
        {
            var plans = LoadPlansFromFile(); // Загружаем существующие планы
            var newPlan = new TrainingPlan
            {
                PlanName = "Новый План",
                Goal = "Цель",
                Days = new List<TrainingDay>()
            };
            plans.Add(newPlan); // Добавляем новый план в список
            SavePlans(plans); // Сохраняем обновленный список

            MessageBox.Show("План успешно сохранён!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void GeneratePlan(object sender, RoutedEventArgs e)
        {
            string goal = (GoalComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            int days = (int)DaysSlider.Value;
            string level = (LevelComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();

            if (string.IsNullOrEmpty(goal) || string.IsNullOrEmpty(level))
            {
                MessageBox.Show("Заполните все поля!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var generator = new PlanGenerator();
            var plan = generator.GeneratePlan(goal, days, level);

            // Пример отображения результата
            string planSummary = $"Цель: {goal}\nДней в неделю: {days}\nУровень: {level}\n";
            foreach (var day in plan.Days)
            {
                planSummary += $"\n{day.DayName}:\n";
                foreach (var exercise in day.Exercises)
                {
                    planSummary += $"- {exercise.Name} ({exercise.Sets}x{exercise.Reps}, отдых: {exercise.RestSeconds} сек)\n";
                }
            }
            MessageBox.Show(planSummary, "Тренировочный план");
        }

        // Метод для загрузки планов из файла
        private List<TrainingPlan> LoadPlansFromFile()
        {
            if (File.Exists(PlansFilePath))
            {
                var json = File.ReadAllText(PlansFilePath);
                return JsonSerializer.Deserialize<List<TrainingPlan>>(json) ?? new List<TrainingPlan>();
            }
            return new List<TrainingPlan>();
        }
        private void BackToMenu(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MenuPage());
        }
    }
}


