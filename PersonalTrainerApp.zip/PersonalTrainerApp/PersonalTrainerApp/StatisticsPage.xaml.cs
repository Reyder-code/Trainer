﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;

namespace PersonalTrainerApp
{
    public partial class StatisticsPage : Page
    {
        private const string PlansFilePath = "plans.json";

        public StatisticsPage()
        {
            InitializeComponent();
            LoadStatistics();
        }

        private void LoadStatistics()
        {
            if (!File.Exists(PlansFilePath))
            {
                TotalPlansText.Text = "0";
                return;
            }

            var json = File.ReadAllText(PlansFilePath);
            var plans = JsonSerializer.Deserialize<List<TrainingPlan>>(json);

            // Total number of training plans
            TotalPlansText.Text = plans.Count.ToString();

            // Most popular goal
            var popularGoal = plans
                .GroupBy(p => p.Goal)
                .OrderByDescending(g => g.Count())
                .FirstOrDefault();



            // Training counts by goal
            var goalCounts = plans
                .GroupBy(p => p.Goal)
                .Select(g => $"{g.Key}: {g.Count()}")
                .ToList();


        }

        private void BackToMenu(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MenuPage());
        }
    }
}



