﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;

namespace PersonalTrainerApp
{
    public partial class MyPlansPage : Page
    {
        private const string PlansFilePath = "plans.json";

        public MyPlansPage()
        {
            InitializeComponent();
            LoadPlans();
        }

        private void LoadPlans()
        {
            if (File.Exists(PlansFilePath))
            {
                var json = File.ReadAllText(PlansFilePath);
                var plans = JsonSerializer.Deserialize<List<TrainingPlan>>(json);
                PlansListBox.ItemsSource = plans;

                // Выводим количество планов в MessageBox
                MessageBox.Show($"Загружено {plans?.Count ?? 0} планов.", "Загрузка планов", MessageBoxButton.OK, MessageBoxImage.Information);

                // Для диагностики выводим имена всех загруженных планов
                if (plans != null)
                {
                    foreach (var plan in plans)
                    {
                        MessageBox.Show($"Загружен план: {plan.PlanName}", "Диагностика загрузки", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
            }
            else
            {
                PlansListBox.ItemsSource = new List<TrainingPlan>();
            }
        }


        private void SavePlans(List<TrainingPlan> plans)
        {
            var json = JsonSerializer.Serialize(plans);
            File.WriteAllText(PlansFilePath, json);
        }

        private void DeletePlan(object sender, RoutedEventArgs e)
        {
            var selectedPlan = PlansListBox.SelectedItem as TrainingPlan;
            if (selectedPlan == null)
            {
                MessageBox.Show("Выберите план для удаления!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var plans = (List<TrainingPlan>)PlansListBox.ItemsSource;
            plans.Remove(selectedPlan);
            SavePlans(plans);

            LoadPlans(); // Refresh the list
            MessageBox.Show("План успешно удалён!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        private void BackToMenu(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MenuPage());
        }
        private void PlansListBox_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            var selectedPlan = PlansListBox.SelectedItem as TrainingPlan;
            if (selectedPlan != null)
            {
                // Формируем строку с подробной информацией о плане
                string planDetails = $"Название плана: {selectedPlan.PlanName}\n" +
                                     $"Цель: {selectedPlan.Goal}\n" +
                                     $"Дней в неделю: {selectedPlan.Days.Count}\n";

                // Перебираем дни тренировки
                foreach (var day in selectedPlan.Days)
                {
                    planDetails += $"\n{day.DayName}:\n";
                    foreach (var exercise in day.Exercises)
                    {
                        planDetails += $"- {exercise.Name} ({exercise.Sets}x{exercise.Reps}, отдых: {exercise.RestSeconds} сек)\n";
                    }
                }

                // Показываем информацию о плане в MessageBox
                MessageBox.Show(planDetails, "Информация о плане", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }





    }
}

