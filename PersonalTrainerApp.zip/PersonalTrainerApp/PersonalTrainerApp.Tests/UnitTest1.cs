﻿using System.Windows;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace PersonalTrainerApp.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestAppStart()
        {
            // Arrange
            bool isWindowOpen = false;

            // Act
            isWindowOpen = false; // Симулируем открытие и закрытие окна

            // Assert
            Assert.IsFalse(isWindowOpen); // Проверяем, что окно не открыто
        }
    }
}
